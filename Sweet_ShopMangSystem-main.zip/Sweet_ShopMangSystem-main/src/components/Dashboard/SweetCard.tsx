import { ShoppingCart, Edit, Trash2, Package } from 'lucide-react';
import type { Database } from '../../lib/database.types';

type Sweet = Database['public']['Tables']['sweets']['Row'];

interface SweetCardProps {
  sweet: Sweet;
  isAdmin: boolean;
  onPurchase: (id: string) => void;
  onEdit: (sweet: Sweet) => void;
  onDelete: (id: string) => void;
  onRestock: (sweet: Sweet) => void;
}

export function SweetCard({ sweet, isAdmin, onPurchase, onEdit, onDelete, onRestock }: SweetCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="h-48 bg-gradient-to-br from-pink-400 to-orange-300 flex items-center justify-center">
        <span className="text-6xl">🍬</span>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-900">{sweet.name}</h3>
          <span className="px-3 py-1 text-xs font-semibold text-blue-600 bg-blue-100 rounded-full">
            {sweet.category}
          </span>
        </div>

        <div className="flex justify-between items-center mb-4">
          <span className="text-2xl font-bold text-gray-900">${sweet.price.toFixed(2)}</span>
          <span className={`text-sm font-medium ${sweet.quantity > 0 ? 'text-green-600' : 'text-red-600'}`}>
            {sweet.quantity > 0 ? `${sweet.quantity} in stock` : 'Out of stock'}
          </span>
        </div>

        <div className="space-y-2">
          {!isAdmin && (
            <button
              onClick={() => onPurchase(sweet.id)}
              disabled={sweet.quantity === 0}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition"
            >
              <ShoppingCart className="w-4 h-4" />
              Purchase
            </button>
          )}

          {isAdmin && (
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => onEdit(sweet)}
                className="flex items-center justify-center gap-1 px-3 py-2 text-sm text-blue-600 bg-blue-50 rounded-md hover:bg-blue-100 transition"
              >
                <Edit className="w-4 h-4" />
                Edit
              </button>
              <button
                onClick={() => onRestock(sweet)}
                className="flex items-center justify-center gap-1 px-3 py-2 text-sm text-green-600 bg-green-50 rounded-md hover:bg-green-100 transition"
              >
                <Package className="w-4 h-4" />
                Stock
              </button>
              <button
                onClick={() => onDelete(sweet.id)}
                className="flex items-center justify-center gap-1 px-3 py-2 text-sm text-red-600 bg-red-50 rounded-md hover:bg-red-100 transition"
              >
                <Trash2 className="w-4 h-4" />
                Delete
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
