import { LogOut, Candy, User, Shield } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export function Header() {
  const { signOut, profile, isAdmin } = useAuth();

  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Candy className="w-8 h-8 text-pink-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Sweet Shop</h1>
              <p className="text-sm text-gray-600">Management System</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-md">
              {isAdmin ? (
                <Shield className="w-4 h-4 text-orange-600" />
              ) : (
                <User className="w-4 h-4 text-blue-600" />
              )}
              <span className="text-sm font-medium text-gray-700">{profile?.email}</span>
              {isAdmin && (
                <span className="ml-2 px-2 py-0.5 text-xs font-semibold text-orange-600 bg-orange-100 rounded">
                  Admin
                </span>
              )}
            </div>
            <button
              onClick={signOut}
              className="flex items-center gap-2 px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700 transition"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
