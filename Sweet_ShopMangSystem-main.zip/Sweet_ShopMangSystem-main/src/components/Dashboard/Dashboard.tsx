import { useState } from 'react';
import { Plus, Loader } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useSweets } from '../../hooks/useSweets';
import { Header } from './Header';
import { SearchBar } from './SearchBar';
import { SweetCard } from './SweetCard';
import { SweetModal } from './SweetModal';
import { RestockModal } from './RestockModal';
import type { Database } from '../../lib/database.types';

type Sweet = Database['public']['Tables']['sweets']['Row'];

export function Dashboard() {
  const { isAdmin } = useAuth();
  const {
    sweets,
    loading,
    error,
    addSweet,
    updateSweet,
    deleteSweet,
    purchaseSweet,
    restockSweet,
    searchSweets,
  } = useSweets();

  const [showModal, setShowModal] = useState(false);
  const [showRestockModal, setShowRestockModal] = useState(false);
  const [editingSweet, setEditingSweet] = useState<Sweet | null>(null);
  const [restockingSweet, setRestockingSweet] = useState<Sweet | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleAddSweet = () => {
    setEditingSweet(null);
    setShowModal(true);
  };

  const handleEditSweet = (sweet: Sweet) => {
    setEditingSweet(sweet);
    setShowModal(true);
  };

  const handleSaveSweet = async (sweetData: Omit<Sweet, 'id' | 'created_at' | 'updated_at' | 'created_by'>) => {
    setActionLoading(true);

    if (editingSweet) {
      const result = await updateSweet(editingSweet.id, sweetData);
      if (result.success) {
        showNotification('success', 'Sweet updated successfully!');
        setShowModal(false);
        setEditingSweet(null);
      } else {
        showNotification('error', result.error || 'Failed to update sweet');
      }
    } else {
      const result = await addSweet(sweetData);
      if (result.success) {
        showNotification('success', 'Sweet added successfully!');
        setShowModal(false);
      } else {
        showNotification('error', result.error || 'Failed to add sweet');
      }
    }

    setActionLoading(false);
  };

  const handleDeleteSweet = async (id: string) => {
    if (!confirm('Are you sure you want to delete this sweet?')) return;

    const result = await deleteSweet(id);
    if (result.success) {
      showNotification('success', 'Sweet deleted successfully!');
    } else {
      showNotification('error', result.error || 'Failed to delete sweet');
    }
  };

  const handlePurchase = async (id: string) => {
    const result = await purchaseSweet(id);
    if (result.success) {
      showNotification('success', 'Purchase successful!');
    } else {
      showNotification('error', result.error || 'Failed to purchase sweet');
    }
  };

  const handleRestockClick = (sweet: Sweet) => {
    setRestockingSweet(sweet);
    setShowRestockModal(true);
  };

  const handleRestock = async (quantity: number) => {
    if (!restockingSweet) return;

    setActionLoading(true);
    const result = await restockSweet(restockingSweet.id, quantity);

    if (result.success) {
      showNotification('success', 'Sweet restocked successfully!');
      setShowRestockModal(false);
      setRestockingSweet(null);
    } else {
      showNotification('error', result.error || 'Failed to restock sweet');
    }

    setActionLoading(false);
  };

  const handleSearch = async (filters: {
    name?: string;
    category?: string;
    minPrice?: number;
    maxPrice?: number;
  }) => {
    await searchSweets(filters);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {notification && (
          <div className={`mb-6 p-4 rounded-md ${
            notification.type === 'success' ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-red-50 text-red-800 border border-red-200'
          }`}>
            {notification.message}
          </div>
        )}

        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Sweet Collection</h2>
            <p className="text-gray-600 mt-1">
              {sweets.length} {sweets.length === 1 ? 'sweet' : 'sweets'} available
            </p>
          </div>
          {isAdmin && (
            <button
              onClick={handleAddSweet}
              className="flex items-center gap-2 px-6 py-3 text-white bg-blue-600 rounded-md hover:bg-blue-700 transition shadow-md hover:shadow-lg"
            >
              <Plus className="w-5 h-5" />
              Add Sweet
            </button>
          )}
        </div>

        <SearchBar onSearch={handleSearch} />

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : error ? (
          <div className="text-center py-20">
            <p className="text-red-600">{error}</p>
          </div>
        ) : sweets.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-gray-600 text-lg">No sweets found. {isAdmin && 'Add your first sweet to get started!'}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sweets.map((sweet) => (
              <SweetCard
                key={sweet.id}
                sweet={sweet}
                isAdmin={isAdmin}
                onPurchase={handlePurchase}
                onEdit={handleEditSweet}
                onDelete={handleDeleteSweet}
                onRestock={handleRestockClick}
              />
            ))}
          </div>
        )}
      </main>

      {showModal && (
        <SweetModal
          sweet={editingSweet}
          onClose={() => {
            setShowModal(false);
            setEditingSweet(null);
          }}
          onSave={handleSaveSweet}
          loading={actionLoading}
        />
      )}

      {showRestockModal && restockingSweet && (
        <RestockModal
          sweet={restockingSweet}
          onClose={() => {
            setShowRestockModal(false);
            setRestockingSweet(null);
          }}
          onRestock={handleRestock}
          loading={actionLoading}
        />
      )}
    </div>
  );
}
