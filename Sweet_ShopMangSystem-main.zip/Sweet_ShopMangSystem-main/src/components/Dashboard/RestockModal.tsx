import { useState } from 'react';
import { X, Package } from 'lucide-react';
import type { Database } from '../../lib/database.types';

type Sweet = Database['public']['Tables']['sweets']['Row'];

interface RestockModalProps {
  sweet: Sweet;
  onClose: () => void;
  onRestock: (quantity: number) => void;
  loading: boolean;
}

export function RestockModal({ sweet, onClose, onRestock, loading }: RestockModalProps) {
  const [quantity, setQuantity] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const qty = parseInt(quantity);
    if (qty > 0) {
      onRestock(qty);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex justify-between items-center p-6 border-b">
          <div className="flex items-center gap-2">
            <Package className="w-6 h-6 text-green-600" />
            <h2 className="text-2xl font-bold text-gray-900">Restock Sweet</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-2">{sweet.name}</h3>
            <p className="text-sm text-gray-600">
              Current Stock: <span className="font-semibold text-gray-900">{sweet.quantity}</span>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">
                Quantity to Add *
              </label>
              <input
                id="quantity"
                type="number"
                min="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter quantity to add"
              />
            </div>

            {quantity && parseInt(quantity) > 0 && (
              <div className="p-3 bg-green-50 rounded-md">
                <p className="text-sm text-green-800">
                  New Stock: <span className="font-semibold">{sweet.quantity + parseInt(quantity)}</span>
                </p>
              </div>
            )}

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                disabled={loading || !quantity || parseInt(quantity) <= 0}
                className="flex-1 px-4 py-2 text-white bg-green-600 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                {loading ? 'Restocking...' : 'Restock'}
              </button>
              <button
                type="button"
                onClick={onClose}
                disabled={loading}
                className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
