/*
  # Sweet Shop Management System - Initial Schema

  ## Overview
  This migration sets up the core database structure for the Sweet Shop Management System,
  including user profiles and sweets inventory management.

  ## New Tables
  
  ### 1. `profiles`
  Extends Supabase auth.users with additional user information:
  - `id` (uuid, primary key, references auth.users)
  - `email` (text, not null)
  - `user_type` (text, not null) - Either 'user' or 'admin'
  - `created_at` (timestamptz) - Timestamp of profile creation
  - `updated_at` (timestamptz) - Timestamp of last update

  ### 2. `sweets`
  Manages the sweet shop inventory:
  - `id` (uuid, primary key) - Unique identifier for each sweet
  - `name` (text, not null) - Name of the sweet
  - `category` (text, not null) - Category (e.g., 'Chocolate', 'Candy', 'Gummy')
  - `price` (numeric, not null) - Price per unit
  - `quantity` (integer, not null) - Available stock quantity
  - `created_at` (timestamptz) - Timestamp of creation
  - `updated_at` (timestamptz) - Timestamp of last update
  - `created_by` (uuid, references profiles) - User who created the sweet

  ## Security
  
  ### Row Level Security (RLS)
  All tables have RLS enabled with the following policies:
  
  #### profiles table:
  - Users can view their own profile
  - Users can update their own profile
  - New profiles are automatically created via trigger on auth.users insert
  
  #### sweets table:
  - All authenticated users can view sweets
  - Only admin users can create sweets
  - Only admin users can update sweets
  - Only admin users can delete sweets
  
  ## Important Notes
  1. The first user registered will need to be manually promoted to admin in the database
  2. All subsequent admin users can be created through the admin interface
  3. Default user_type is 'user' for new registrations
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  user_type text NOT NULL DEFAULT 'user' CHECK (user_type IN ('user', 'admin')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create sweets table
CREATE TABLE IF NOT EXISTS sweets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  price numeric(10, 2) NOT NULL CHECK (price >= 0),
  quantity integer NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES profiles(id)
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE sweets ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Sweets policies for SELECT (all authenticated users)
CREATE POLICY "Authenticated users can view sweets"
  ON sweets FOR SELECT
  TO authenticated
  USING (true);

-- Sweets policies for INSERT (admin only)
CREATE POLICY "Admin users can create sweets"
  ON sweets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.user_type = 'admin'
    )
  );

-- Sweets policies for UPDATE (admin only)
CREATE POLICY "Admin users can update sweets"
  ON sweets FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.user_type = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.user_type = 'admin'
    )
  );

-- Sweets policies for DELETE (admin only)
CREATE POLICY "Admin users can delete sweets"
  ON sweets FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.user_type = 'admin'
    )
  );

-- Create function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, email, user_type)
  VALUES (new.id, new.email, 'user');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically create profile on user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers
DROP TRIGGER IF EXISTS set_updated_at_profiles ON profiles;
CREATE TRIGGER set_updated_at_profiles
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_sweets ON sweets;
CREATE TRIGGER set_updated_at_sweets
  BEFORE UPDATE ON sweets
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();